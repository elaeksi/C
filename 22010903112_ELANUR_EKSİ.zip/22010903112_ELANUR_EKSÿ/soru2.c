#include <stdio.h>
#include <stdlib.h>

#define MAX_STRINGS	10
#define STRING_LENGTH 50

int main()
{
	
	char ad_soyad[MAX_STRINGS][STRING_LENGTH];
    char tarih[MAX_STRINGS][STRING_LENGTH];
    char saat[MAX_STRINGS][STRING_LENGTH];
	int loop,n=0,kayit_cikis=0,tarih_sayac,control,saat_control;
	
	
	
	printf("Enter strings...\n");
    while(kayit_cikis == 0){
        tarih_sayac = 0;
        printf("Kayit --[%d]--",n+1);

        printf("\nAd Soyad = "); 
        getchar();
        scanf("%[^\n]s",ad_soyad[n]);

        //TARİH KONTROLÜ
        do{
        control = 0;
        printf("Randevu Tarih Giriniz (gunayyil) =");        
        getchar();
        scanf("%[^\n]s",tarih[n]);

        for(loop=0; loop<n; loop++)
	    {
            if ( atoi(tarih[loop]) == atoi(tarih[n])){
                tarih_sayac += 1;
            }
	    }

        if (tarih_sayac > 4){
            printf("Randevu Tarihi Dolu Yeni Bir Tarih Belirleyiniz \n"); 
            control = 1;
            
            tarih_sayac = 0;
        }        
        }while(control == 1);


        //SAAT KONTROLÜ
        do{
        saat_control = 0;
        printf("Randevu Saati Giriniz   saat (16:50)* ise giris (1650) olmali =");        
        getchar();
        scanf("%[^\n]s",saat[n]);

        for(loop=0; loop<n; loop++)
	    {
            if ( atoi(tarih[loop]) == atoi(tarih[n])){
                if ( atoi(saat[loop]) == atoi(saat[n])){
                saat_control += 1;
                printf("\nRandevu Saati Dolu Yeni Bir Saat Belirleyiniz.");  
                }
            }            
	    }       

        }while(saat_control == 1);




        
        printf("Kayit cikisi icin 1 girisi, Kayit girisi icin 0 girisi yapin = ");
        scanf("%d",&kayit_cikis);
        n += 1;
    }
	
	
	printf("\nKayitlar...\n");
	for(loop=0; loop<n; loop++)
	{
		printf("[%2d] AD SOYAD: %s\n",loop+1,ad_soyad[loop]);
        printf("[%2d]RANDEVU TARIHI: %s\n",loop+1,tarih[loop]);
        printf("[%2d]RANDEVU SAATI: %s\n",loop+1,saat[loop]);
	}
	
	return 0;
}