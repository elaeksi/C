#include <stdio.h>
#include <stdlib.h>

int main(){

    int sayac = 0, bossayac=0, etsayac=0, noksayac=0;
    char sesli_harf[] = {'a','e','i','o','u','A','E','I','O','U'};
    char cumle[1000];
    char bosluk=' ';
    char nokta='.';
    char et='@';
    char sessiz_harf = {'b','B','c','C','d','D','f','F','g','G','h','H','j','J','k','K','l','L','m','M','n','N','p','P','r','R','s','S','t','T','v','V','y','Y','z','Z','q','Q','w','W','x','X'};

    printf("Bir cumle giriniz(turkce karaktersiz ): ");
    gets(cumle);
    // bosluklu ifadeleri okumak icin kullanılır.
    

    
    for (int i = 0; i < strlen(cumle); i++)
    {
        for(int j = 0; j < 10; j++)
        {
            if(cumle[i] == sesli_harf[j]){
                sayac++;
            }
        }
        
        if(cumle[i] == nokta)
        {
            noksayac++;
        }
        if(cumle[i] == et)
        {
            etsayac++;
        }
    }
    printf("\nGirilen metinde %d adet sesli haf vardir", sayac);
    printf("\nGirilen metinde ki sessiz harf sayisi %d'dir.", sessiz_harf);
    printf("\nGirilen metinde %d adet cumle vardir.", noksayac);
    printf("\nGirilen metinde  %d adet eposta vardir.", etsayac);

}
    