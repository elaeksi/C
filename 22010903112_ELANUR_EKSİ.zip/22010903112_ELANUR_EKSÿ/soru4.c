#include <stdio.h>
#include <stdlib.h>
int main()
{
   int i, sayi, sayi1, sayi2, sayac=0, sayac1=0, sayac2=0;
   printf("Bir sayi giriniz: ");
   scanf("%d",&sayi);
   
   while (0>sayi)
   {
      printf("Hatali giris yaptiniz.\n");
      printf("Bir sayi giriniz: ");
      scanf("%d",&sayi);
   }
   
   
   sayi1=sayi+2;
   sayi2=sayi+6;

   for(i=2;i<sayi;i++)
   {
      if(sayi%i==0)
      {
         sayac++;
      }
   }
   for(i=2;i<sayi1;i++)
   {
      if(sayi1%i==0)
      {
         sayac1++;
      }
   }
   for(i=2;i<sayi2;i++)
   {
      if(sayi2%i==0)
      {
         sayac2++;
      }
   }
   if(sayac==0 && sayi>1 && sayac1==0 && sayi1>1 && sayac2==0 && sayi2>1)
   {
      printf("Asal ucuzdur.");
   }
   else{
      printf("Asal ucuz degildir.");
   }


}
    